// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}
function combineRgb(r, g, b, a) {
  let colorNumber = (r & 255) << 16 | (g & 255) << 8 | b & 255;
  if (a && a >= 0 && a < 1) {
    colorNumber += 16777216 * Math.round(255 * (1 - a));
  }
  return colorNumber;
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path, args) {
    this.#context.oscSend(host, port, path, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// src/main.js
import { execFile } from "child_process";
var MAX_RUNDOWN_SLOTS = 20;
var COLOR = {
  green: combineRgb(76, 175, 80),
  amber: combineRgb(255, 152, 0),
  red: combineRgb(244, 67, 54),
  overtime: combineRgb(156, 39, 176),
  paused: combineRgb(96, 125, 139),
  stopped: combineRgb(85, 85, 85),
  white: combineRgb(255, 255, 255),
  dimwhite: combineRgb(180, 180, 180),
  darkgrey: combineRgb(30, 30, 30),
  blue: combineRgb(13, 71, 161),
  darkred: combineRgb(183, 28, 28),
  darkgreen: combineRgb(46, 125, 50),
  highlight: combineRgb(30, 80, 160),
  clock: combineRgb(0, 105, 120),
  message: combineRgb(120, 80, 0)
};
var COUNT_STYLES = [
  { id: "down", label: "Count down (stops at 0:00)" },
  { id: "downUp", label: "Down, then up (counts the overrun)" },
  { id: "up", label: "Count up (stopwatch from 0:00)" }
];
var FoxyTimerInstance = class extends InstanceBase {
  async init(config) {
    this.config = config;
    this.roomStates = /* @__PURE__ */ new Map();
    this.pollTimers = /* @__PURE__ */ new Map();
    this.selected = /* @__PURE__ */ new Map();
    this.lastTake = /* @__PURE__ */ new Map();
    this.updateStatus(InstanceStatus.Connecting);
    this._watchTimeZone();
    this._setupPolling();
    this._initAll();
  }
  async destroy() {
    this._stopPolling();
    clearInterval(this.tzTimer);
  }
  // This PC's time zone, for the "Ends at" time of day. Node reads the zone once
  // when the module starts, so a laptop moved to another zone mid-trip (UK ->
  // Europe) would show the old one until Companion restarts. A fresh process
  // always sees the current zone: ask one every minute.
  _watchTimeZone() {
    this.tzOffsetMin = (/* @__PURE__ */ new Date()).getTimezoneOffset();
    const env = { ...process.env, ELECTRON_RUN_AS_NODE: "1" };
    delete env.TZ;
    const check = () => execFile(
      process.execPath,
      ["-e", "process.stdout.write(String(new Date().getTimezoneOffset()))"],
      { timeout: 5e3, windowsHide: true, env },
      (err, out) => {
        const v = parseInt(out, 10);
        if (!err && Number.isFinite(v)) this.tzOffsetMin = v;
      }
    );
    check();
    this.tzTimer = setInterval(check, 6e4);
  }
  async configUpdated(config) {
    this.config = config;
    this._stopPolling();
    this.roomStates = /* @__PURE__ */ new Map();
    this._setupPolling();
    this._initAll();
  }
  getConfigFields() {
    return [
      {
        type: "textinput",
        id: "host",
        label: "Server URL",
        default: "http://localhost:3000",
        tooltip: "Base URL of your Foxy Presentation Timer server (no trailing slash)",
        width: 12
      },
      {
        type: "textinput",
        id: "apiKey",
        label: "Client API Key",
        default: "",
        tooltip: "Your client API key (see scripts/create-client.js on the server). Required since the server now authenticates every request.",
        width: 12
      },
      {
        type: "textinput",
        id: "rooms",
        label: "Room IDs to monitor (comma-separated)",
        default: "",
        tooltip: "Room slugs shown in the control panel header \u2014 e.g.  main-stage,workshop-a. Must belong to the client the API key above authenticates as.",
        width: 12
      },
      {
        type: "number",
        id: "pollInterval",
        label: "Poll interval (ms)",
        default: 1e3,
        min: 500,
        max: 1e4,
        step: 100,
        tooltip: "1000 ms (1 second) is recommended for smooth time display",
        width: 6
      },
      {
        type: "dropdown",
        id: "presetSize",
        label: "Preset text size",
        default: "14",
        choices: [
          { id: "auto", label: "Auto" },
          { id: "7", label: "7" },
          { id: "14", label: "14" },
          { id: "18", label: "18" },
          { id: "24", label: "24" },
          { id: "30", label: "30" }
        ],
        tooltip: "Text size for buttons dragged in from Presets (Start, Clock, 5 MIN...). Buttons showing names and times stay on Auto so long names fit. Buttons already on your pages keep their size.",
        width: 6
      }
    ];
  }
  _rooms() {
    return (this.config?.rooms || "").split(",").map((r) => r.trim()).filter(Boolean);
  }
  _base() {
    return (this.config?.host || "http://localhost:3000").replace(/\/$/, "");
  }
  _headers() {
    return { Authorization: `Bearer ${this.config?.apiKey || ""}` };
  }
  _prefix(roomId) {
    return roomId.replace(/[^a-zA-Z0-9]/g, "_").toLowerCase();
  }
  _initAll() {
    this._initVariables();
    this._initActions();
    this._initFeedbacks();
    this._initPresets();
    if (this._rooms().length === 0) {
      this.updateStatus(InstanceStatus.BadConfig, "No rooms configured");
    }
  }
  _setupPolling() {
    const ms = this.config?.pollInterval || 1e3;
    for (const roomId of this._rooms()) {
      this._pollRoom(roomId);
      this.pollTimers.set(roomId, setInterval(() => this._pollRoom(roomId), ms));
    }
  }
  _stopPolling() {
    for (const t of this.pollTimers.values()) clearInterval(t);
    this.pollTimers.clear();
  }
  async _pollRoom(roomId) {
    const url = `${this._base()}/api/rooms/${encodeURIComponent(roomId)}/companion`;
    try {
      const res = await fetch(url, { headers: this._headers(), signal: AbortSignal.timeout(5e3) });
      if (res.status === 401) {
        this.updateStatus(InstanceStatus.AuthenticationFailure, "API key rejected - check the Client API Key setting");
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const state = await res.json();
      this.roomStates.set(roomId, state);
      this._followLive(roomId, state);
      this._syncVariables(roomId, state);
      this._refreshFeedbacks();
      this.updateStatus(InstanceStatus.Ok);
    } catch (err) {
      this.log("warn", `Poll failed for "${roomId}": ${err.message}`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Cannot reach ${this._base()}`);
    }
  }
  _initVariables() {
    const defs = {};
    for (const roomId of this._rooms()) {
      const p = this._prefix(roomId);
      defs[`${p}_time`] = { name: `[${roomId}] Time remaining` };
      defs[`${p}_mode`] = { name: `[${roomId}] Mode` };
      defs[`${p}_color`] = { name: `[${roomId}] Colour hint` };
      defs[`${p}_speaker`] = { name: `[${roomId}] Current speaker` };
      defs[`${p}_next_speaker`] = { name: `[${roomId}] Next speaker` };
      defs[`${p}_position`] = { name: `[${roomId}] Running order position (e.g. 3/8)` };
      defs[`${p}_rundown_count`] = { name: `[${roomId}] Running order \u2014 total items` };
      defs[`${p}_display_shows`] = { name: `[${roomId}] Display shows (TIMER / CLOCK)` };
      defs[`${p}_count_style`] = { name: `[${roomId}] How the timer counts (down / downUp / up)` };
      defs[`${p}_speed`] = { name: `[${roomId}] Timer speed (e.g. 1.05x)` };
      defs[`${p}_ends_at`] = { name: `[${roomId}] Ends at (time of day it reaches 0:00, this PC's clock)` };
      defs[`${p}_controller`] = { name: `[${roomId}] Device in control` };
      defs[`${p}_takeover`] = { name: `[${roomId}] Handover request waiting (e.g. "Laura's iPad asks \xB7 12s"), else blank` };
      defs[`${p}_selected`] = { name: `[${roomId}] Running order: selected item (what TAKE loads)` };
      defs[`${p}_selected_pos`] = { name: `[${roomId}] Running order: selected item position (e.g. 4/12)` };
      for (let i = 1; i <= MAX_RUNDOWN_SLOTS; i++) {
        defs[`${p}_rundown_${i}`] = { name: `[${roomId}] Running order slot ${i} name` };
      }
    }
    this.setVariableDefinitions(defs);
  }
  _refreshFeedbacks() {
    this.checkFeedbacks(
      "timer_color",
      "timer_running",
      "timer_paused",
      "timer_stopped",
      "rundown_item_active",
      "display_shows",
      "count_style",
      "timer_on_start",
      "message_showing",
      "speed_changed",
      "rundown_slot",
      "take_ready",
      "takeover_waiting",
      "duration_is"
    );
  }
  // The selected item (what TAKE will load) is the one AFTER the live item, so
  // TAKE, TAKE, TAKE walks through the show. Prev/Next/slots move it; it only
  // jumps again when the live item changes (from here or anywhere else).
  _followLive(roomId, state) {
    const count = (state.rundown || []).length;
    const live = Number.isInteger(state.rundownIndex) ? state.rundownIndex : -1;
    const cur = this.selected.get(roomId);
    if (cur && cur.live === live && cur.count === count) return;
    const index = count === 0 ? -1 : live < 0 ? 0 : Math.min(live + 1, count - 1);
    this.selected.set(roomId, { index, live, count });
  }
  _select(roomId, index) {
    const cur = this.selected.get(roomId);
    const state = this.roomStates.get(roomId);
    if (!cur || !state || cur.count === 0) return;
    cur.index = Math.max(0, Math.min(cur.count - 1, index));
    this._syncVariables(roomId, state);
    this._refreshFeedbacks();
  }
  _syncVariables(roomId, state) {
    const p = this._prefix(roomId);
    const vals = {
      [`${p}_time`]: state.timeDisplay || "--:--",
      [`${p}_mode`]: state.modeLabel || "",
      [`${p}_color`]: state.color || "",
      [`${p}_speaker`]: state.speaker || "",
      [`${p}_next_speaker`]: state.nextSpeaker || "",
      [`${p}_position`]: state.rundownPos || "",
      [`${p}_rundown_count`]: String((state.rundown || []).length),
      [`${p}_display_shows`]: state.outputMode === "clock" ? "CLOCK" : "TIMER",
      [`${p}_count_style`]: state.countStyle || "down",
      [`${p}_speed`]: `${Number(state.speed || 1).toFixed(2)}x`,
      [`${p}_ends_at`]: state.endsAtMs ? this._clock(state.endsAtMs) : "--:--",
      [`${p}_controller`]: state.controller || "Nobody",
      [`${p}_takeover`]: state.takeOverRequest ? `${state.takeOverRequest.requesterName} asks \xB7 ${state.takeOverRequest.secondsLeft}s` : ""
    };
    const sel = this.selected.get(roomId);
    const item = sel && sel.index >= 0 ? (state.rundown || [])[sel.index] : null;
    vals[`${p}_selected`] = item ? item.name || "" : "";
    vals[`${p}_selected_pos`] = item ? `${sel.index + 1}/${sel.count}` : "";
    const rundown = state.rundown || [];
    for (let i = 1; i <= MAX_RUNDOWN_SLOTS; i++) {
      vals[`${p}_rundown_${i}`] = rundown[i - 1]?.name || "";
    }
    this.setVariableValues(vals);
  }
  // Time of day on this PC, 24-hour, e.g. 14:32 (the show's local time), in the
  // PC's current zone (see _watchTimeZone).
  _clock(ms) {
    const offset = Number.isFinite(this.tzOffsetMin) ? this.tzOffsetMin : new Date(ms).getTimezoneOffset();
    const d = new Date(ms - offset * 6e4);
    return `${String(d.getUTCHours()).padStart(2, "0")}:${String(d.getUTCMinutes()).padStart(2, "0")}`;
  }
  async _post(path, body) {
    const res = await fetch(`${this._base()}${path}`, {
      method: "POST",
      headers: { ...this._headers(), ...body ? { "Content-Type": "application/json" } : {} },
      body: body ? JSON.stringify(body) : void 0,
      signal: AbortSignal.timeout(5e3)
    });
    if (res.status === 401) {
      this.updateStatus(InstanceStatus.AuthenticationFailure, "API key rejected - check the Client API Key setting");
      throw new Error("401 Unauthorized - check the Client API Key setting");
    }
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
  }
  _initActions() {
    const firstRoom = this._rooms()[0] || "";
    const roomField = {
      type: "textinput",
      id: "roomId",
      label: "Room ID",
      default: firstRoom,
      tooltip: "Room ID shown in the control panel header"
    };
    this.setActionDefinitions({
      start: { name: "Start Timer", options: [roomField], callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/start`).catch((e) => this.log("error", e.message)) },
      pause: { name: "Pause Timer", options: [roomField], callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/pause`).catch((e) => this.log("error", e.message)) },
      resume: { name: "Resume Timer", options: [roomField], callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/resume`).catch((e) => this.log("error", e.message)) },
      reset: { name: "Reset Timer", options: [roomField], callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/reset`).catch((e) => this.log("error", e.message)) },
      toggle: {
        name: "Toggle \u2014 Start \u2192 Pause \u2192 Resume",
        description: "Smart toggle: starts if stopped, pauses if running, resumes if paused",
        options: [roomField],
        callback: async (a) => {
          const state = this.roomStates.get(a.options.roomId);
          const endpoint = state?.mode === "running" ? "pause" : state?.mode === "paused" ? "resume" : "start";
          await this._post(`/api/rooms/${a.options.roomId}/${endpoint}`).catch((e) => this.log("error", e.message));
        }
      },
      nudge: {
        name: "Nudge Timer",
        options: [
          roomField,
          { type: "dropdown", id: "ms", label: "Amount", default: "60000", choices: [
            { id: "300000", label: "+5 minutes" },
            { id: "60000", label: "+1 minute" },
            { id: "30000", label: "+30 seconds" },
            { id: "10000", label: "+10 seconds" },
            { id: "-10000", label: "\u221210 seconds" },
            { id: "-30000", label: "\u221230 seconds" },
            { id: "-60000", label: "\u22121 minute" },
            { id: "-300000", label: "\u22125 minutes" }
          ] }
        ],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/nudge`, { ms: parseInt(a.options.ms) }).catch((e) => this.log("error", e.message))
      },
      set_duration: {
        name: "Set Duration",
        description: "Like a control-page preset: sets the Duration for the next Start or Reset. A running timer keeps going.",
        options: [
          roomField,
          { type: "dropdown", id: "durationMs", label: "Duration", default: "1800000", choices: [
            { id: "300000", label: "5 min" },
            { id: "600000", label: "10 min" },
            { id: "900000", label: "15 min" },
            { id: "1200000", label: "20 min" },
            { id: "1500000", label: "25 min" },
            { id: "1800000", label: "30 min" },
            { id: "2100000", label: "35 min" },
            { id: "2400000", label: "40 min" },
            { id: "2700000", label: "45 min" },
            { id: "3600000", label: "60 min" },
            { id: "5400000", label: "90 min" }
          ] }
        ],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/set-duration`, { durationMs: parseInt(a.options.durationMs) }).catch((e) => this.log("error", e.message))
      },
      rundown_prev: {
        name: "Running order \u2014 Load previous item now (stops the timer)",
        description: 'Loads the previous item onto the display straight away and stops the timer. For browsing, use "Select previous".',
        options: [roomField],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/rundown/prev`).catch((e) => this.log("error", e.message))
      },
      rundown_next: {
        name: "Running order \u2014 Load next item now (stops the timer)",
        description: 'Loads the next item onto the display straight away and stops the timer. For browsing, use "Select next".',
        options: [roomField],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/rundown/next`).catch((e) => this.log("error", e.message))
      },
      rundown_take: {
        name: "Running order \u2014 Restart the loaded item",
        description: 'Starts the item already on the display from its full length. To go on to the selected item, use "Take selected".',
        options: [roomField],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/rundown/take`).catch((e) => this.log("error", e.message))
      },
      rundown_goto: {
        name: "Running order \u2014 Load slot now (stops the timer)",
        description: 'Loads a slot onto the display straight away and stops the timer. For browsing, use "Select slot".',
        options: [
          roomField,
          { type: "number", id: "slot", label: "Slot number (1 = first)", default: 1, min: 1, max: MAX_RUNDOWN_SLOTS }
        ],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/rundown/goto`, { index: a.options.slot - 1 }).catch((e) => this.log("error", e.message))
      },
      rundown_select_prev: {
        name: "Running order \u2014 Select previous",
        description: "Moves the selection up. Nothing changes on the display until TAKE.",
        options: [roomField],
        callback: (a) => this._select(a.options.roomId, (this.selected.get(a.options.roomId)?.index ?? 0) - 1)
      },
      rundown_select_next: {
        name: "Running order \u2014 Select next",
        description: "Moves the selection down. Nothing changes on the display until TAKE.",
        options: [roomField],
        callback: (a) => this._select(a.options.roomId, (this.selected.get(a.options.roomId)?.index ?? -1) + 1)
      },
      rundown_select: {
        name: "Running order \u2014 Select slot",
        description: "Selects a slot. Nothing changes on the display until TAKE.",
        options: [roomField, { type: "number", id: "slot", label: "Slot number (1 = first)", default: 1, min: 1, max: MAX_RUNDOWN_SLOTS }],
        callback: (a) => this._select(a.options.roomId, a.options.slot - 1)
      },
      rundown_take_selected: {
        name: "Running order \u2014 Take selected (load and start)",
        description: "Loads the selected item onto the display and starts it; the selection then moves to the next item. A second press within 2 seconds is ignored, and so is TAKE on the item already running.",
        options: [roomField],
        callback: async (a) => {
          const roomId = a.options.roomId;
          const sel = this.selected.get(roomId);
          const state = this.roomStates.get(roomId);
          if (!sel || sel.index < 0 || !state) return;
          if (sel.index === state.rundownIndex && state.mode === "running") return;
          const now = Date.now();
          if (now - (this.lastTake.get(roomId) || 0) < 2e3) return;
          this.lastTake.set(roomId, now);
          await this._post(`/api/rooms/${roomId}/rundown/goto`, { index: sel.index, autoStart: true }).catch((e) => this.log("error", e.message));
          this._pollRoom(roomId);
        }
      },
      takeover_answer: {
        name: "Handover \u2014 Allow / Refuse",
        description: `Answers a device asking to take control (the room's "Ask before handing over" setting). Does nothing when nobody is asking.`,
        options: [roomField, { type: "dropdown", id: "allow", label: "Answer", default: "no", choices: [{ id: "no", label: "Refuse" }, { id: "yes", label: "Allow" }] }],
        callback: async (a) => {
          if (!this.roomStates.get(a.options.roomId)?.takeOverRequest) return;
          await this._post(`/api/rooms/${a.options.roomId}/takeover`, { allow: a.options.allow === "yes" }).catch((e) => this.log("error", e.message));
          this._pollRoom(a.options.roomId);
        }
      },
      display_shows: {
        name: "Display shows \u2014 Timer / Clock",
        description: "Switch the display between the timer and the time of day",
        options: [
          roomField,
          { type: "dropdown", id: "mode", label: "Show", default: "toggle", choices: [
            { id: "timer", label: "Timer" },
            { id: "clock", label: "Clock (time of day)" },
            { id: "toggle", label: "Toggle Timer / Clock" }
          ] }
        ],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/output`, { mode: a.options.mode }).catch((e) => this.log("error", e.message))
      },
      timer_on_start: {
        name: "Back to timer on Start \u2014 On / Off",
        description: "When on, starting the timer switches a display that is showing the clock back to the timer",
        options: [
          roomField,
          { type: "dropdown", id: "value", label: "Set", default: "toggle", choices: [
            { id: "on", label: "On" },
            { id: "off", label: "Off" },
            { id: "toggle", label: "Toggle" }
          ] }
        ],
        callback: async (a) => {
          const current = !!this.roomStates.get(a.options.roomId)?.timerOnStart;
          const value = a.options.value === "toggle" ? !current : a.options.value === "on";
          await this._post(`/api/rooms/${a.options.roomId}/settings`, { timerOnStart: value }).catch((e) => this.log("error", e.message));
        }
      },
      speed: {
        name: "Timer speed",
        description: "Run the timer faster or slower than real time (the control page's Timer speed). The time shown never jumps; only the rate changes.",
        options: [
          roomField,
          { type: "dropdown", id: "step", label: "Change", default: "0.05", choices: [
            { id: "0.05", label: "Faster (+0.05x)" },
            { id: "-0.05", label: "Slower (-0.05x)" },
            { id: "0.1", label: "Faster (+0.10x)" },
            { id: "-0.1", label: "Slower (-0.10x)" },
            { id: "normal", label: "Normal speed (1x)" }
          ] }
        ],
        callback: async (a) => {
          const body = a.options.step === "normal" ? { speed: 1 } : { speedStep: parseFloat(a.options.step) };
          await this._post(`/api/rooms/${a.options.roomId}/settings`, body).catch((e) => this.log("error", e.message));
        }
      },
      count_style: {
        name: "How the timer counts",
        description: "Count down, down then up, or count up (stopwatch)",
        options: [roomField, { type: "dropdown", id: "style", label: "Count", default: "down", choices: COUNT_STYLES }],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/settings`, { style: a.options.style }).catch((e) => this.log("error", e.message))
      },
      message: {
        name: "Message to the display",
        description: "Show a message full screen or as a ticker. Variables are allowed in the text.",
        options: [
          roomField,
          { type: "textinput", id: "text", label: "Message", default: "", useVariables: true },
          { type: "dropdown", id: "mode", label: "Show as", default: "overlay", choices: [
            { id: "overlay", label: "Full screen (hides the timer)" },
            { id: "ticker", label: "Ticker (scrolls above the timer)" }
          ] }
        ],
        callback: async (a, context) => {
          const text = await context.parseVariablesInString(a.options.text || "");
          await this._post(`/api/rooms/${a.options.roomId}/message`, { text, mode: a.options.mode }).catch((e) => this.log("error", e.message));
        }
      },
      message_clear: {
        name: "Message to the display \u2014 Clear",
        options: [roomField],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/message`, { text: "", mode: "none" }).catch((e) => this.log("error", e.message))
      }
    });
  }
  _initFeedbacks() {
    const firstRoom = this._rooms()[0] || "";
    const roomField = { type: "textinput", id: "roomId", label: "Room ID", default: firstRoom };
    this.setFeedbackDefinitions({
      timer_color: {
        type: "advanced",
        name: "Timer Colour (background)",
        description: "Button background follows timer state: green \u2192 amber \u2192 red \u2192 purple (overtime) / blue-grey (paused) / dark grey (stopped)",
        options: [roomField],
        callback: (fb) => {
          const state = this.roomStates.get(fb.options.roomId);
          if (!state) return {};
          return { bgcolor: COLOR[state.color] ?? COLOR.stopped };
        }
      },
      timer_running: {
        type: "boolean",
        name: "Timer is Running",
        description: "True while the timer is actively counting",
        defaultStyle: { bgcolor: COLOR.green },
        options: [roomField],
        callback: (fb) => this.roomStates.get(fb.options.roomId)?.mode === "running"
      },
      timer_paused: {
        type: "boolean",
        name: "Timer is Paused",
        description: "True while the timer is paused",
        defaultStyle: { bgcolor: COLOR.paused },
        options: [roomField],
        callback: (fb) => this.roomStates.get(fb.options.roomId)?.mode === "paused"
      },
      timer_stopped: {
        type: "boolean",
        name: "Timer is Stopped / Ready",
        description: "True when the timer has not yet started or was reset",
        defaultStyle: { bgcolor: COLOR.stopped },
        options: [roomField],
        callback: (fb) => this.roomStates.get(fb.options.roomId)?.mode === "stopped"
      },
      rundown_item_active: {
        type: "boolean",
        name: "Running order item is currently live",
        description: "True when the specified running order slot is the currently loaded speaker. Use on running order slot buttons to highlight the live slot.",
        defaultStyle: { bgcolor: COLOR.highlight, color: COLOR.white },
        options: [
          roomField,
          { type: "number", id: "position", label: "Slot number (1 = first speaker)", default: 1, min: 1, max: MAX_RUNDOWN_SLOTS }
        ],
        callback: (fb) => {
          const state = this.roomStates.get(fb.options.roomId);
          if (!state || state.rundownIndex < 0) return false;
          return state.rundownIndex + 1 === Number(fb.options.position);
        }
      },
      rundown_slot: {
        type: "advanced",
        name: "Running order slot (live / selected)",
        description: "The live item takes the timer colour; the selected item (what TAKE loads) is blue; the rest stay as they are.",
        options: [roomField, { type: "number", id: "position", label: "Slot number (1 = first)", default: 1, min: 1, max: MAX_RUNDOWN_SLOTS }],
        callback: (fb) => {
          const state = this.roomStates.get(fb.options.roomId);
          if (!state) return {};
          const i = Number(fb.options.position) - 1;
          if (i === state.rundownIndex) return { bgcolor: COLOR[state.color] ?? COLOR.stopped, color: COLOR.white };
          if (i === this.selected.get(fb.options.roomId)?.index) return { bgcolor: COLOR.highlight, color: COLOR.white };
          return {};
        }
      },
      take_ready: {
        type: "boolean",
        name: "TAKE would start something",
        description: "True when an item is selected that is not already running",
        defaultStyle: { bgcolor: COLOR.darkgreen, color: COLOR.white },
        options: [roomField],
        callback: (fb) => {
          const state = this.roomStates.get(fb.options.roomId);
          const sel = this.selected.get(fb.options.roomId);
          return !!state && !!sel && sel.index >= 0 && !(sel.index === state.rundownIndex && state.mode === "running");
        }
      },
      takeover_waiting: {
        type: "advanced",
        name: "Handover request waiting (flashes)",
        description: "Flashes amber while a device is asking to take control",
        options: [roomField],
        callback: (fb) => {
          const req = this.roomStates.get(fb.options.roomId)?.takeOverRequest;
          if (!req) return {};
          const on = Math.floor(Date.now() / 1e3) % 2 === 0;
          return { bgcolor: on ? COLOR.amber : COLOR.darkred, color: COLOR.white };
        }
      },
      duration_is: {
        type: "boolean",
        name: "Duration setting is",
        description: "True while the Duration setting (what Start and Reset use) is this length",
        defaultStyle: { bgcolor: COLOR.highlight, color: COLOR.white },
        options: [roomField, { type: "number", id: "minutes", label: "Minutes", default: 30, min: 0, max: 600 }],
        callback: (fb) => this.roomStates.get(fb.options.roomId)?.configDurationMs === Number(fb.options.minutes) * 6e4
      },
      display_shows: {
        type: "boolean",
        name: "Display shows Timer / Clock",
        description: "True while the display shows the chosen one",
        defaultStyle: { bgcolor: COLOR.clock, color: COLOR.white },
        options: [roomField, { type: "dropdown", id: "mode", label: "Shows", default: "clock", choices: [{ id: "timer", label: "Timer" }, { id: "clock", label: "Clock" }] }],
        callback: (fb) => {
          const state = this.roomStates.get(fb.options.roomId);
          return !!state && (state.outputMode === "clock" ? "clock" : "timer") === fb.options.mode;
        }
      },
      count_style: {
        type: "boolean",
        name: "Timer counts this way",
        description: "True while the timer counts the chosen way",
        defaultStyle: { bgcolor: COLOR.highlight, color: COLOR.white },
        options: [roomField, { type: "dropdown", id: "style", label: "Count", default: "down", choices: COUNT_STYLES }],
        callback: (fb) => (this.roomStates.get(fb.options.roomId)?.countStyle || "down") === fb.options.style
      },
      speed_changed: {
        type: "boolean",
        name: "Timer speed is not normal",
        description: "True while the timer runs faster or slower than real time",
        defaultStyle: { bgcolor: COLOR.amber, color: COLOR.white },
        options: [roomField],
        callback: (fb) => {
          const v = this.roomStates.get(fb.options.roomId)?.speed;
          return !!v && Math.abs(v - 1) > 1e-3;
        }
      },
      timer_on_start: {
        type: "boolean",
        name: "Back to timer on Start is on",
        defaultStyle: { bgcolor: COLOR.highlight, color: COLOR.white },
        options: [roomField],
        callback: (fb) => !!this.roomStates.get(fb.options.roomId)?.timerOnStart
      },
      message_showing: {
        type: "boolean",
        name: "A message is showing on the display",
        defaultStyle: { bgcolor: COLOR.message, color: COLOR.white },
        options: [roomField],
        callback: (fb) => {
          const m = this.roomStates.get(fb.options.roomId)?.messageMode;
          return !!m && m !== "none";
        }
      }
    });
  }
  // Presets, grouped the way a show runs: Show (what's happening), Run (the
  // timer), Running order, Display, Setup (before the show).
  _initPresets() {
    const structure = [];
    const presets = {};
    const L = this.config?.presetSize || "14";
    const none = [{ down: [], up: [] }];
    const press = (actionId, options) => [{ down: [{ actionId, options }], up: [] }];
    const add = (list, id, preset) => {
      list.push(id);
      presets[id] = { type: "simple", ...preset };
    };
    for (const roomId of this._rooms()) {
      const p = this._prefix(roomId);
      const v = (name) => `$(self:${p}_${name})`;
      const show = [];
      add(show, `${p}_status`, { name: "Time + speaker (timer colour)", style: { text: `${v("time")}
${v("speaker")}`, size: "auto", color: COLOR.white, bgcolor: COLOR.stopped }, feedbacks: [{ feedbackId: "timer_color", options: { roomId } }], steps: none });
      add(show, `${p}_next`, { name: "Up next", style: { text: `UP NEXT
${v("next_speaker")}`, size: "auto", color: COLOR.dimwhite, bgcolor: COLOR.darkgrey }, feedbacks: [], steps: none });
      add(show, `${p}_position`, { name: "Running order position (e.g. 3/8)", style: { text: `ITEM
${v("position")}`, size: L, color: COLOR.white, bgcolor: COLOR.darkgrey }, feedbacks: [], steps: none });
      add(show, `${p}_ends_at`, { name: "Ends at (time of day)", style: { text: `ENDS
${v("ends_at")}`, size: L, color: COLOR.white, bgcolor: COLOR.darkgrey }, feedbacks: [], steps: none });
      add(show, `${p}_in_control`, {
        name: "In control: flashes when a device asks to take over; press = Refuse",
        style: { text: `IN CONTROL
${v("controller")}`, size: "auto", color: COLOR.dimwhite, bgcolor: COLOR.darkgrey },
        feedbacks: [{ feedbackId: "takeover_waiting", options: { roomId } }],
        steps: press("takeover_answer", { roomId, allow: "no" })
      });
      add(show, `${p}_allow`, {
        name: "Allow handover (lights while a device is asking)",
        style: { text: "ALLOW\nHANDOVER", size: L, color: COLOR.dimwhite, bgcolor: COLOR.darkgrey },
        feedbacks: [{ feedbackId: "takeover_waiting", options: { roomId } }],
        steps: press("takeover_answer", { roomId, allow: "yes" })
      });
      structure.push({ id: `${p}_show`, name: `${roomId} \u2014 Show`, definitions: show });
      const run = [];
      add(run, `${p}_toggle`, {
        name: "Start / Pause / Resume",
        // Lit like the control page's key: green running (press to pause), amber paused (press to resume).
        style: { text: "\u25B6 START", size: L, color: COLOR.green, bgcolor: COLOR.darkgrey },
        feedbacks: [
          { feedbackId: "timer_running", options: { roomId }, style: { text: "\u23F8 PAUSE", color: COLOR.white, bgcolor: COLOR.darkgreen } },
          { feedbackId: "timer_paused", options: { roomId }, style: { text: "\u25B6 RESUME", color: COLOR.white, bgcolor: COLOR.amber } }
        ],
        steps: press("toggle", { roomId })
      });
      add(run, `${p}_reset`, { name: "Reset", style: { text: "\u25A0 RESET", size: L, color: COLOR.red, bgcolor: COLOR.darkgrey }, feedbacks: [], steps: press("reset", { roomId }) });
      for (const [label, ms] of [["-5 MIN", "-300000"], ["-1 MIN", "-60000"], ["-30 SEC", "-30000"], ["+30 SEC", "30000"], ["+1 MIN", "60000"], ["+5 MIN", "300000"]]) {
        add(run, `${p}_nudge_${ms.replace("-", "minus")}`, { name: label, style: { text: label, size: L, color: COLOR.white, bgcolor: COLOR.darkgrey }, feedbacks: [], steps: press("nudge", { roomId, ms }) });
      }
      for (const [step, label] of [["-0.05", "SLOWER"], ["normal", "SPEED"], ["0.05", "FASTER"]]) {
        add(run, `${p}_speed_${step.replace("-", "minus").replace(".", "_")}`, {
          name: step === "normal" ? "Speed: shows it; press = back to normal (amber when not 1x)" : `Speed: ${label.toLowerCase()} (0.05x)`,
          style: { text: step === "normal" ? `SPEED
${v("speed")}` : label, size: L, color: COLOR.white, bgcolor: COLOR.darkgrey },
          feedbacks: step === "normal" ? [{ feedbackId: "speed_changed", options: { roomId }, style: { bgcolor: COLOR.amber } }] : [],
          steps: press("speed", { roomId, step })
        });
      }
      structure.push({ id: `${p}_run`, name: `${roomId} \u2014 Run`, definitions: run });
      const order = [];
      add(order, `${p}_prog_prev`, { name: "Select previous", style: { text: "\u25B2 PREV", size: L, color: COLOR.white, bgcolor: COLOR.darkgrey }, feedbacks: [], steps: press("rundown_select_prev", { roomId }) });
      add(order, `${p}_prog_take`, {
        name: "TAKE: load and start the selected item (shows it)",
        style: { text: `TAKE ${v("selected_pos")}
${v("selected")}`, size: "auto", color: COLOR.dimwhite, bgcolor: COLOR.darkgrey },
        feedbacks: [{ feedbackId: "take_ready", options: { roomId }, style: { bgcolor: COLOR.darkgreen, color: COLOR.white } }],
        steps: press("rundown_take_selected", { roomId })
      });
      add(order, `${p}_prog_next`, { name: "Select next", style: { text: "NEXT \u25BC", size: L, color: COLOR.white, bgcolor: COLOR.darkgrey }, feedbacks: [], steps: press("rundown_select_next", { roomId }) });
      for (let i = 1; i <= MAX_RUNDOWN_SLOTS; i++) {
        add(order, `${p}_prog_${i}`, {
          name: `Slot ${i} (press = select; live = timer colour, selected = blue)`,
          style: { text: `${i}. ${v(`rundown_${i}`)}`, size: "auto", color: COLOR.dimwhite, bgcolor: COLOR.darkgrey },
          feedbacks: [{ feedbackId: "rundown_slot", options: { roomId, position: i } }],
          steps: press("rundown_select", { roomId, slot: i })
        });
      }
      structure.push({ id: `${p}_programme`, name: `${roomId} \u2014 Running order`, definitions: order });
      const disp = [];
      for (const [mode, label] of [["timer", "TIMER"], ["clock", "CLOCK"]]) {
        add(disp, `${p}_show_${mode}`, {
          name: `Show the ${mode} (lit while showing)`,
          style: { text: label, size: L, color: COLOR.white, bgcolor: COLOR.darkgrey },
          feedbacks: [{ feedbackId: "display_shows", options: { roomId, mode }, style: { bgcolor: mode === "clock" ? COLOR.clock : COLOR.darkgreen } }],
          steps: press("display_shows", { roomId, mode })
        });
      }
      add(disp, `${p}_msg_wrap`, {
        name: "Message: Please wrap up (edit the text)",
        style: { text: "WRAP UP", size: L, color: COLOR.white, bgcolor: COLOR.darkgrey },
        feedbacks: [{ feedbackId: "message_showing", options: { roomId }, style: { bgcolor: COLOR.message } }],
        steps: press("message", { roomId, text: "Please wrap up", mode: "overlay" })
      });
      add(disp, `${p}_msg_clear`, {
        name: "Clear message (lit while one is showing)",
        style: { text: "CLEAR MSG", size: L, color: COLOR.white, bgcolor: COLOR.darkgrey },
        feedbacks: [{ feedbackId: "message_showing", options: { roomId }, style: { bgcolor: COLOR.message } }],
        steps: press("message_clear", { roomId })
      });
      structure.push({ id: `${p}_display`, name: `${roomId} \u2014 Display`, definitions: disp });
      const setup = [];
      for (const min of [5, 10, 15, 20, 25, 30, 35, 45]) {
        add(setup, `${p}_dur_${min}`, {
          name: `Duration ${min} min (for the next Start/Reset; lit when set)`,
          style: { text: `${min} MIN`, size: L, color: COLOR.white, bgcolor: COLOR.darkgrey },
          feedbacks: [{ feedbackId: "duration_is", options: { roomId, minutes: min } }],
          steps: press("set_duration", { roomId, durationMs: String(min * 6e4) })
        });
      }
      for (const [style, label] of [["down", "COUNT DOWN"], ["downUp", "DOWN THEN UP"], ["up", "COUNT UP"]]) {
        add(setup, `${p}_count_${style.toLowerCase()}`, {
          name: COUNT_STYLES.find((c) => c.id === style).label,
          style: { text: label, size: L, color: COLOR.white, bgcolor: COLOR.darkgrey },
          feedbacks: [{ feedbackId: "count_style", options: { roomId, style }, style: { bgcolor: COLOR.highlight } }],
          steps: press("count_style", { roomId, style })
        });
      }
      add(setup, `${p}_timer_on_start`, {
        name: "Back to timer on Start (on/off)",
        style: { text: "TIMER ON START", size: L, color: COLOR.dimwhite, bgcolor: COLOR.darkgrey },
        feedbacks: [{ feedbackId: "timer_on_start", options: { roomId }, style: { bgcolor: COLOR.highlight, color: COLOR.white } }],
        steps: press("timer_on_start", { roomId, value: "toggle" })
      });
      structure.push({ id: `${p}_setup`, name: `${roomId} \u2014 Setup`, definitions: setup });
    }
    this.setPresetDefinitions(structure, presets);
  }
};
var UpgradeScripts = [];
var main_default = FoxyTimerInstance;
export {
  UpgradeScripts,
  main_default as default
};
