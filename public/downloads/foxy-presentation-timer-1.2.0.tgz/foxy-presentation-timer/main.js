// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}
function combineRgb(r, g, b, a) {
  let colorNumber = (r & 255) << 16 | (g & 255) << 8 | b & 255;
  if (a && a >= 0 && a < 1) {
    colorNumber += 16777216 * Math.round(255 * (1 - a));
  }
  return colorNumber;
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables) {
    if (Array.isArray(variables))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path, args) {
    this.#context.oscSend(host, port, path, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// src/main.js
var MAX_RUNDOWN_SLOTS = 20;
var COLOR = {
  green: combineRgb(76, 175, 80),
  amber: combineRgb(255, 152, 0),
  red: combineRgb(244, 67, 54),
  overtime: combineRgb(156, 39, 176),
  paused: combineRgb(96, 125, 139),
  stopped: combineRgb(85, 85, 85),
  white: combineRgb(255, 255, 255),
  dimwhite: combineRgb(180, 180, 180),
  darkgrey: combineRgb(30, 30, 30),
  blue: combineRgb(13, 71, 161),
  darkred: combineRgb(183, 28, 28),
  darkgreen: combineRgb(46, 125, 50),
  highlight: combineRgb(30, 80, 160)
};
var FoxyTimerInstance = class extends InstanceBase {
  async init(config) {
    this.config = config;
    this.roomStates = /* @__PURE__ */ new Map();
    this.pollTimers = /* @__PURE__ */ new Map();
    this.updateStatus(InstanceStatus.Connecting);
    this._setupPolling();
    this._initAll();
  }
  async destroy() {
    this._stopPolling();
  }
  async configUpdated(config) {
    this.config = config;
    this._stopPolling();
    this.roomStates = /* @__PURE__ */ new Map();
    this._setupPolling();
    this._initAll();
  }
  getConfigFields() {
    return [
      {
        type: "textinput",
        id: "host",
        label: "Server URL",
        default: "http://localhost:3000",
        tooltip: "Base URL of your Foxy Presentation Timer server (no trailing slash)",
        width: 12
      },
      {
        type: "textinput",
        id: "apiKey",
        label: "Client API Key",
        default: "",
        tooltip: "Your client API key (see scripts/create-client.js on the server). Required since the server now authenticates every request.",
        width: 12
      },
      {
        type: "textinput",
        id: "rooms",
        label: "Room IDs to monitor (comma-separated)",
        default: "",
        tooltip: "Room slugs shown in the control panel header \u2014 e.g.  main-stage,workshop-a. Must belong to the client the API key above authenticates as.",
        width: 12
      },
      {
        type: "number",
        id: "pollInterval",
        label: "Poll interval (ms)",
        default: 1e3,
        min: 500,
        max: 1e4,
        step: 100,
        tooltip: "1000 ms (1 second) is recommended for smooth time display",
        width: 6
      }
    ];
  }
  _rooms() {
    return (this.config?.rooms || "").split(",").map((r) => r.trim()).filter(Boolean);
  }
  _base() {
    return (this.config?.host || "http://localhost:3000").replace(/\/$/, "");
  }
  _headers() {
    return { Authorization: `Bearer ${this.config?.apiKey || ""}` };
  }
  _prefix(roomId) {
    return roomId.replace(/[^a-zA-Z0-9]/g, "_").toLowerCase();
  }
  _initAll() {
    this._initVariables();
    this._initActions();
    this._initFeedbacks();
    this._initPresets();
    if (this._rooms().length === 0) {
      this.updateStatus(InstanceStatus.BadConfig, "No rooms configured");
    }
  }
  _setupPolling() {
    const ms = this.config?.pollInterval || 1e3;
    for (const roomId of this._rooms()) {
      this._pollRoom(roomId);
      this.pollTimers.set(roomId, setInterval(() => this._pollRoom(roomId), ms));
    }
  }
  _stopPolling() {
    for (const t of this.pollTimers.values()) clearInterval(t);
    this.pollTimers.clear();
  }
  async _pollRoom(roomId) {
    const url = `${this._base()}/api/rooms/${encodeURIComponent(roomId)}/companion`;
    try {
      const res = await fetch(url, { headers: this._headers(), signal: AbortSignal.timeout(5e3) });
      if (res.status === 401) {
        this.updateStatus(InstanceStatus.AuthenticationFailure, "API key rejected - check the Client API Key setting");
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const state = await res.json();
      this.roomStates.set(roomId, state);
      this._syncVariables(roomId, state);
      this.checkFeedbacks("timer_color", "timer_running", "timer_paused", "timer_stopped", "rundown_item_active");
      this.updateStatus(InstanceStatus.Ok);
    } catch (err) {
      this.log("warn", `Poll failed for "${roomId}": ${err.message}`);
      this.updateStatus(InstanceStatus.ConnectionFailure, `Cannot reach ${this._base()}`);
    }
  }
  _initVariables() {
    const defs = {};
    for (const roomId of this._rooms()) {
      const p = this._prefix(roomId);
      defs[`${p}_time`] = { name: `[${roomId}] Time remaining` };
      defs[`${p}_mode`] = { name: `[${roomId}] Mode` };
      defs[`${p}_color`] = { name: `[${roomId}] Colour hint` };
      defs[`${p}_speaker`] = { name: `[${roomId}] Current speaker` };
      defs[`${p}_next_speaker`] = { name: `[${roomId}] Next speaker` };
      defs[`${p}_position`] = { name: `[${roomId}] Rundown position (e.g. 3/8)` };
      defs[`${p}_rundown_count`] = { name: `[${roomId}] Rundown \u2014 total items` };
      for (let i = 1; i <= MAX_RUNDOWN_SLOTS; i++) {
        defs[`${p}_rundown_${i}`] = { name: `[${roomId}] Rundown slot ${i} name` };
      }
    }
    this.setVariableDefinitions(defs);
  }
  _syncVariables(roomId, state) {
    const p = this._prefix(roomId);
    const vals = {
      [`${p}_time`]: state.timeDisplay || "--:--",
      [`${p}_mode`]: state.modeLabel || "",
      [`${p}_color`]: state.color || "",
      [`${p}_speaker`]: state.speaker || "",
      [`${p}_next_speaker`]: state.nextSpeaker || "",
      [`${p}_position`]: state.rundownPos || "",
      [`${p}_rundown_count`]: String((state.rundown || []).length)
    };
    const rundown = state.rundown || [];
    for (let i = 1; i <= MAX_RUNDOWN_SLOTS; i++) {
      vals[`${p}_rundown_${i}`] = rundown[i - 1]?.name || "";
    }
    this.setVariableValues(vals);
  }
  async _post(path, body) {
    const res = await fetch(`${this._base()}${path}`, {
      method: "POST",
      headers: { ...this._headers(), ...body ? { "Content-Type": "application/json" } : {} },
      body: body ? JSON.stringify(body) : void 0,
      signal: AbortSignal.timeout(5e3)
    });
    if (res.status === 401) {
      this.updateStatus(InstanceStatus.AuthenticationFailure, "API key rejected - check the Client API Key setting");
      throw new Error("401 Unauthorized - check the Client API Key setting");
    }
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
  }
  _initActions() {
    const firstRoom = this._rooms()[0] || "";
    const roomField = {
      type: "textinput",
      id: "roomId",
      label: "Room ID",
      default: firstRoom,
      tooltip: "Room ID shown in the control panel header"
    };
    this.setActionDefinitions({
      start: { name: "Start Timer", options: [roomField], callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/start`).catch((e) => this.log("error", e.message)) },
      pause: { name: "Pause Timer", options: [roomField], callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/pause`).catch((e) => this.log("error", e.message)) },
      resume: { name: "Resume Timer", options: [roomField], callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/resume`).catch((e) => this.log("error", e.message)) },
      reset: { name: "Reset Timer", options: [roomField], callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/reset`).catch((e) => this.log("error", e.message)) },
      toggle: {
        name: "Toggle \u2014 Start \u2192 Pause \u2192 Resume",
        description: "Smart toggle: starts if stopped, pauses if running, resumes if paused",
        options: [roomField],
        callback: async (a) => {
          const state = this.roomStates.get(a.options.roomId);
          const endpoint = state?.mode === "running" ? "pause" : state?.mode === "paused" ? "resume" : "start";
          await this._post(`/api/rooms/${a.options.roomId}/${endpoint}`).catch((e) => this.log("error", e.message));
        }
      },
      nudge: {
        name: "Nudge Timer",
        options: [
          roomField,
          { type: "dropdown", id: "ms", label: "Amount", default: "60000", choices: [
            { id: "300000", label: "+5 minutes" },
            { id: "60000", label: "+1 minute" },
            { id: "30000", label: "+30 seconds" },
            { id: "10000", label: "+10 seconds" },
            { id: "-10000", label: "\u221210 seconds" },
            { id: "-30000", label: "\u221230 seconds" },
            { id: "-60000", label: "\u22121 minute" },
            { id: "-300000", label: "\u22125 minutes" }
          ] }
        ],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/nudge`, { ms: parseInt(a.options.ms) }).catch((e) => this.log("error", e.message))
      },
      set_duration: {
        name: "Set Duration",
        options: [
          roomField,
          { type: "dropdown", id: "durationMs", label: "Duration", default: "1800000", choices: [
            { id: "300000", label: "5 min" },
            { id: "600000", label: "10 min" },
            { id: "900000", label: "15 min" },
            { id: "1200000", label: "20 min" },
            { id: "1500000", label: "25 min" },
            { id: "1800000", label: "30 min" },
            { id: "2700000", label: "45 min" },
            { id: "3600000", label: "60 min" }
          ] }
        ],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/set-duration`, { durationMs: parseInt(a.options.durationMs) }).catch((e) => this.log("error", e.message))
      },
      rundown_prev: {
        name: "Rundown \u2014 Previous item",
        description: "Load the previous rundown item and stop the timer",
        options: [roomField],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/rundown/prev`).catch((e) => this.log("error", e.message))
      },
      rundown_next: {
        name: "Rundown \u2014 Next item",
        description: "Load the next rundown item and stop the timer",
        options: [roomField],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/rundown/next`).catch((e) => this.log("error", e.message))
      },
      rundown_take: {
        name: "Rundown \u2014 Take (start current item)",
        description: "Start the currently loaded rundown item. If nothing is loaded, loads and starts the first item.",
        options: [roomField],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/rundown/take`).catch((e) => this.log("error", e.message))
      },
      rundown_goto: {
        name: "Rundown \u2014 Go to slot",
        description: "Navigate to a specific rundown slot (1 = first speaker). Does not start the timer.",
        options: [
          roomField,
          { type: "number", id: "slot", label: "Slot number (1 = first)", default: 1, min: 1, max: MAX_RUNDOWN_SLOTS }
        ],
        callback: async (a) => this._post(`/api/rooms/${a.options.roomId}/rundown/goto`, { index: a.options.slot - 1 }).catch((e) => this.log("error", e.message))
      }
    });
  }
  _initFeedbacks() {
    const firstRoom = this._rooms()[0] || "";
    const roomField = { type: "textinput", id: "roomId", label: "Room ID", default: firstRoom };
    this.setFeedbackDefinitions({
      timer_color: {
        type: "advanced",
        name: "Timer Colour (background)",
        description: "Button background follows timer state: green \u2192 amber \u2192 red \u2192 purple (overtime) / blue-grey (paused) / dark grey (stopped)",
        options: [roomField],
        callback: (fb) => {
          const state = this.roomStates.get(fb.options.roomId);
          if (!state) return {};
          return { bgcolor: COLOR[state.color] ?? COLOR.stopped };
        }
      },
      timer_running: {
        type: "boolean",
        name: "Timer is Running",
        description: "True while the timer is actively counting",
        defaultStyle: { bgcolor: COLOR.green },
        options: [roomField],
        callback: (fb) => this.roomStates.get(fb.options.roomId)?.mode === "running"
      },
      timer_paused: {
        type: "boolean",
        name: "Timer is Paused",
        description: "True while the timer is paused",
        defaultStyle: { bgcolor: COLOR.paused },
        options: [roomField],
        callback: (fb) => this.roomStates.get(fb.options.roomId)?.mode === "paused"
      },
      timer_stopped: {
        type: "boolean",
        name: "Timer is Stopped / Ready",
        description: "True when the timer has not yet started or was reset",
        defaultStyle: { bgcolor: COLOR.stopped },
        options: [roomField],
        callback: (fb) => this.roomStates.get(fb.options.roomId)?.mode === "stopped"
      },
      rundown_item_active: {
        type: "boolean",
        name: "Rundown item is currently live",
        description: "True when the specified rundown slot is the currently loaded speaker. Use on programme board buttons to highlight the live slot.",
        defaultStyle: { bgcolor: COLOR.highlight, color: COLOR.white },
        options: [
          roomField,
          { type: "number", id: "position", label: "Slot number (1 = first speaker)", default: 1, min: 1, max: MAX_RUNDOWN_SLOTS }
        ],
        callback: (fb) => {
          const state = this.roomStates.get(fb.options.roomId);
          if (!state || state.rundownIndex < 0) return false;
          return state.rundownIndex + 1 === Number(fb.options.position);
        }
      }
    });
  }
  _initPresets() {
    const structure = [];
    const presets = {};
    for (const roomId of this._rooms()) {
      const p = this._prefix(roomId);
      structure.push({ id: `${p}_timer`, name: `${roomId} \u2014 Timer`, definitions: [`${p}_status`, `${p}_next`, `${p}_position`] });
      presets[`${p}_status`] = { type: "simple", name: "Status: time + speaker", style: { text: `$(self:${p}_time)
$(self:${p}_speaker)`, size: "auto", color: COLOR.white, bgcolor: COLOR.stopped }, feedbacks: [{ feedbackId: "timer_color", options: { roomId } }], steps: [{ down: [], up: [] }] };
      presets[`${p}_next`] = { type: "simple", name: "Up next: next speaker", style: { text: `Up next:
$(self:${p}_next_speaker)`, size: "auto", color: COLOR.dimwhite, bgcolor: COLOR.darkgrey }, feedbacks: [], steps: [{ down: [], up: [] }] };
      presets[`${p}_position`] = { type: "simple", name: "Rundown position counter", style: { text: `$(self:${p}_position)
$(self:${p}_speaker)`, size: "auto", color: COLOR.white, bgcolor: COLOR.darkgrey }, feedbacks: [{ feedbackId: "timer_color", options: { roomId } }], steps: [{ down: [], up: [] }] };
      const controlIds = [`${p}_toggle`, `${p}_reset`];
      presets[`${p}_toggle`] = {
        type: "simple",
        name: "Start / Pause / Resume (smart toggle)",
        style: { text: "\u25B6 START", size: "auto", color: COLOR.white, bgcolor: COLOR.darkgreen },
        feedbacks: [
          { feedbackId: "timer_running", options: { roomId }, style: { text: "\u23F8 PAUSE", bgcolor: COLOR.amber } },
          { feedbackId: "timer_paused", options: { roomId }, style: { text: "\u25B6 RESUME", bgcolor: COLOR.darkgreen } }
        ],
        steps: [{ down: [{ actionId: "toggle", options: { roomId } }], up: [] }]
      };
      presets[`${p}_reset`] = { type: "simple", name: "Reset", style: { text: "\u21BA RESET", size: "auto", color: COLOR.white, bgcolor: COLOR.stopped }, feedbacks: [], steps: [{ down: [{ actionId: "reset", options: { roomId } }], up: [] }] };
      for (const [label, ms, bg] of [
        ["+5 MIN", "300000", COLOR.blue],
        ["+1 MIN", "60000", COLOR.blue],
        ["+30 SEC", "30000", COLOR.blue],
        ["-30 SEC", "-30000", COLOR.darkred],
        ["-1 MIN", "-60000", COLOR.darkred],
        ["-5 MIN", "-300000", COLOR.darkred]
      ]) {
        const safe = label.replace(/[^a-zA-Z0-9]/g, "_").toLowerCase();
        const id = `${p}_nudge_${safe}`;
        controlIds.push(id);
        presets[id] = { type: "simple", name: label, style: { text: label, size: "auto", color: COLOR.white, bgcolor: bg }, feedbacks: [], steps: [{ down: [{ actionId: "nudge", options: { roomId, ms } }], up: [] }] };
      }
      structure.push({ id: `${p}_controls`, name: `${roomId} \u2014 Controls`, definitions: controlIds });
      const durationIds = [];
      for (const [label, durationMs] of [
        ["5 MIN", "300000"],
        ["10 MIN", "600000"],
        ["15 MIN", "900000"],
        ["20 MIN", "1200000"],
        ["30 MIN", "1800000"],
        ["45 MIN", "2700000"],
        ["60 MIN", "3600000"]
      ]) {
        const safe = label.replace(/[^a-zA-Z0-9]/g, "_").toLowerCase();
        const id = `${p}_dur_${safe}`;
        durationIds.push(id);
        presets[id] = { type: "simple", name: `Set ${label}`, style: { text: label, size: "auto", color: COLOR.white, bgcolor: combineRgb(40, 40, 80) }, feedbacks: [], steps: [{ down: [{ actionId: "set_duration", options: { roomId, durationMs } }], up: [] }] };
      }
      structure.push({ id: `${p}_durations`, name: `${roomId} \u2014 Durations`, definitions: durationIds });
      presets[`${p}_prog_prev`] = {
        type: "simple",
        name: "Programme \u2014 Previous",
        style: { text: "\u25C0 PREV", size: "auto", color: COLOR.white, bgcolor: COLOR.stopped },
        feedbacks: [],
        steps: [{ down: [{ actionId: "rundown_prev", options: { roomId } }], up: [] }]
      };
      presets[`${p}_prog_take`] = {
        type: "simple",
        name: "Programme \u2014 Take (start current)",
        style: { text: "\u25B6 TAKE", size: "auto", color: COLOR.white, bgcolor: COLOR.darkgreen },
        feedbacks: [{ feedbackId: "timer_running", options: { roomId }, style: { text: "\u25B6 TAKE", bgcolor: COLOR.green } }],
        steps: [{ down: [{ actionId: "rundown_take", options: { roomId } }], up: [] }]
      };
      presets[`${p}_prog_next`] = {
        type: "simple",
        name: "Programme \u2014 Next",
        style: { text: "NEXT \u25B6", size: "auto", color: COLOR.white, bgcolor: COLOR.stopped },
        feedbacks: [],
        steps: [{ down: [{ actionId: "rundown_next", options: { roomId } }], up: [] }]
      };
      const progIds = [`${p}_prog_prev`, `${p}_prog_take`, `${p}_prog_next`];
      for (let i = 1; i <= MAX_RUNDOWN_SLOTS; i++) {
        const id = `${p}_prog_${i}`;
        progIds.push(id);
        presets[id] = {
          type: "simple",
          name: `Slot ${i}`,
          style: { text: `${i}. $(self:${p}_rundown_${i})`, size: "auto", color: COLOR.white, bgcolor: COLOR.darkgrey },
          feedbacks: [
            { feedbackId: "rundown_item_active", options: { roomId, position: i }, style: { bgcolor: COLOR.highlight } },
            { feedbackId: "timer_color", options: { roomId } }
          ],
          steps: [{ down: [{ actionId: "rundown_goto", options: { roomId, slot: i } }], up: [] }]
        };
      }
      structure.push({ id: `${p}_programme`, name: `${roomId} \u2014 Programme`, definitions: progIds });
    }
    this.setPresetDefinitions(structure, presets);
  }
};
var UpgradeScripts = [];
var main_default = FoxyTimerInstance;
export {
  UpgradeScripts,
  main_default as default
};
